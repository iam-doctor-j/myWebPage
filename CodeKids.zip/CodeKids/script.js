var button = document.getElementById('start-button');
var form = document.getElementById('_loginPage');
var mainPage = document.getElementById('_mainPage');

button.onclick=function(){
	if(form.getAttribute('is-hidden')==='hidden'){
		form.setAttribute('is-hidden','shown');
		mainPage.classList.remove('col-12');
		mainPage.classList.add('col-7');
		form.classList.remove('d-none');
	}
}
